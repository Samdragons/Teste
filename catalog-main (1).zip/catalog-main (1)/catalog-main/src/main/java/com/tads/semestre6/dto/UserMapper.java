package com.tads.semestre6.dto;

import com.tads.semestre6.entities.User;

public class UserMapper {

    public User mapToUser(UserDTO dto){
        return User.builder()
                .email(dto.getEmail())
                .name(dto.getName())
                .password(dto.getPassword())
                .build()

    }
}
