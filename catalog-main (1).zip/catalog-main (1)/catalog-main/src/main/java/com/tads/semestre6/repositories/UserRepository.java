package com.tads.semestre6.repositories;

import com.tads.semestre6.entities.User;

public interface UserRepository {
    User findByEmail(String email);

}
