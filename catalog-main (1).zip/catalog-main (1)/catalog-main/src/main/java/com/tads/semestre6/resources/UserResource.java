package com.tads.semestre6.resources;

import com.tads.semestre6.dto.UserMapper;
import com.tads.semestre6.entities.User;
import com.tads.semestre6.servicesInterface.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("users")
@RequiredArgsContructor

public class UserResource {
    private final UserService userService;
    private final UserMapper userMapper;

    public ResponseEntity save(@RequestBody userDTO dto){
        try {
            User user = userMapper.mapToUser(dto);
            userService
        }
    }
}
