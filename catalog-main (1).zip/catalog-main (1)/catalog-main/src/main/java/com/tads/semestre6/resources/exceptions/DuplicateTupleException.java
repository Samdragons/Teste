package com.tads.semestre6.resources.exceptions;

public class DuplicateTupleException {
}
