package com.tads.semestre6;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class AccessToken {
    private String accessToken;

}
