package com.tads.semestre6.dto;

public class UserDTO {
    private String name;
    private String email;
    private String password;


}
