package com.tads.semestre6.entities;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table
@EntityListener(AuditingEntityListener.class)
@Data

public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String id;
    @Column
    private String name;
    @Column
    private String email;
    @Column
    private String password;

    @CratedDate
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    public static User builder() {
        return null;
    }
}