package com.tads.semestre6.servicesInterface;


import com.tads.semestre6.entities.User;

public interface UserService {
    User getByEmail(String email);
    User save(User user);
    AccesToken autenticate (String email, String password);

}
