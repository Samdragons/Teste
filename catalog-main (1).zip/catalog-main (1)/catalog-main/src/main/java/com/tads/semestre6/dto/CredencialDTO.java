package com.tads.semestre6.dto;

public class CredencialDTO {

    private String email;
    private String password;
}
